#pragma once
#include <iostream>
class MatrixH
{
public:
	double H[4][4];
	void print();
};

